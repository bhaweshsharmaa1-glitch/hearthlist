﻿using System.Windows;

namespace Hearthlist.Desktop;

public partial class App : Application
{
    private Hearthlist.Backend.HearthlistApp? _backend;

    public Hearthlist.Backend.HearthlistApp Backend => _backend!;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // No StartupUri in XAML — we init the backend first, then show the window.
        _backend = new Hearthlist.Backend.HearthlistApp();
        await _backend.StartAsync();

        var window = new MainWindow(this);
        MainWindow = window;
        window.Show();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _backend?.DisposeAsync().AsTask().GetAwaiter().GetResult();
        base.OnExit(e);
    }
}
